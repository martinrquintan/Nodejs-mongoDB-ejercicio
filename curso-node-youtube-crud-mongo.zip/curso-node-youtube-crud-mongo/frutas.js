const frutas = ['platano', 'manzana', 'platano', 'pera'];
const dinero = 1000;

module.exports = {
    frutas: frutas,
    dinero
}